﻿
namespace EFPractical.Data.Infrastructure
{
    public interface IUnitOfWork
    {
        void Commit();
    }
}
