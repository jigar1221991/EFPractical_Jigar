﻿using EFPractical.Data.Models;

namespace EFPractical.Data.Infrastructure
{
public class DatabaseFactory : Disposable, IDatabaseFactory
{
    private EFPracticalEntities dataContext;
    public EFPracticalEntities Get()
    {
        return dataContext ?? (dataContext = new EFPracticalEntities());
    }
    protected override void DisposeCore()
    {
        if (dataContext != null)
            dataContext.Dispose();
    }
}
}
