﻿using System;
using EFPractical.Data.Models;

namespace EFPractical.Data.Infrastructure
{
    public interface IDatabaseFactory : IDisposable
    {
        EFPracticalEntities Get();
    }
}
