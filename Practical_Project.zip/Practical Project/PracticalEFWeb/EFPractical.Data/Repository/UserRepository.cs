﻿using EFPractical.Data.Infrastructure;
using EFPratical.Model.Models;
using System;
using System.Linq.Expressions;
namespace EFPractical.Data.Repository
{
    public class UserRepository: RepositoryBase<ApplicationUser>, IUserRepository
        {
        public UserRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
            {
            }        
        }
    public interface IUserRepository : IRepository<ApplicationUser>
    {
        
    }
}