﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EFPractical.Data.Infrastructure;
using EFPratical.Model.Models;

namespace EFPractical.Data.Repository
{
    class UpdateSupportRepository : RepositoryBase<UpdateSupport>, IUpdateSupportRepository
    {
        public UpdateSupportRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }
    public interface IUpdateSupportRepository : IRepository<UpdateSupport>
    {
    }
}
