﻿
using System;
namespace EFPratical.Model.Models
{
    public class GroupUpdateUser
    {
        public int GroupUpdateUserId { get; set; }

        public int GroupUpdateId { get; set; }

        public string UserId { get; set; }


    }
}
