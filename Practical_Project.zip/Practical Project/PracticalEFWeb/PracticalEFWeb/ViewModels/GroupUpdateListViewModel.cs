﻿using System;
using System.Collections.Generic;
using EFPratical.Model.Models;


namespace PracticalEFWeb.ViewModels
{
    public class GroupUpdateListViewModel
    {
        public IEnumerable<GroupUpdateViewModel> GroupUpdates { get; set; }

        public double? Target { get; set; }

        public Metric Metric { get; set; }
    }
}