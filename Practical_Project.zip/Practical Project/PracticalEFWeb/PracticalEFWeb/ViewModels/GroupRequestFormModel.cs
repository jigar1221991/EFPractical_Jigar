﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PracticalEFWeb.ViewModels
{
    public class GroupRequestFormModel
    {
        public int GroupId { get; set; }

        public string UserId { get; set; }
    }
}