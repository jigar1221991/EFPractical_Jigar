﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PracticalEFWeb.Startup))]
namespace PracticalEFWeb
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
